"""Package local source work and the latest previews without deleting trials."""
import hashlib,json,shutil,zipfile
from pathlib import Path
from animation_runtime import REPOSITORY

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    base=REPOSITORY/'output/pet-walk-batch2'
    destination=REPOSITORY/'AnimationDrafts/2026-10-28';destination.mkdir(exist_ok=True)
    files=set((base/'walk-painted-v7/generated').glob('*.png'))
    files.add(base/'walk-painted-v7/generation-prompts.json')
    files.update((base/'walk-painted-v7').glob('*pose-guide.png'))
    for role in ['xiaobai','dafeiyu']:
        files.update((base/'walk-painted-v7'/role/'keys').glob('*.png'))
        files.update((base/'walk-painted-v10'/role/'inputs').glob('*.png'))
        files.update((base/'walk-painted-v10'/role/'frames-60fps').glob('*.png'))
        files.update((base/'walk-painted-v11'/role/'frames-60fps').glob('*.png'))
        files.add(base/'walk-painted-v11'/role/'joints.json')
    files.update((base/'walk-painted-v11').glob('*.json'))
    files.add(base/'walk-painted-v11/reference-comparison.png')
    for pattern in ['*walk*.py','animation_runtime.py','port_animation_drafts.py','fetch_animation_rife.py']:
        files.update((REPOSITORY/'Scripts').glob(pattern))
    records=[]
    archive=destination/'sources.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as target:
        for file in sorted(files):
            relative=file.relative_to(REPOSITORY).as_posix()
            records.append(dict(path=relative,bytes=file.stat().st_size,sha256=sha(file)))
            target.write(file,relative)
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        for record in records:
            assert hashlib.sha256(check.read(record['path'])).hexdigest()==record['sha256']
    previews=destination/'previews';previews.mkdir(exist_ok=True);videos=[]
    for name in ['pet-walk-full-v11.mp4','human-feet-v11.mp4','pet-feet-v11.mp4']:
        source=base/'walk-painted-v11'/name;target=previews/name;shutil.copy2(source,target)
        videos.append(dict(path='previews/'+name,bytes=target.stat().st_size,sha256=sha(target)))
    manifest=dict(status='unaccepted_local_draft',branch='codex/character-chat',base_commit='bafc996fb3a70cace014d182163af863e90c1713',
        archive=dict(path='sources.zip',bytes=archive.stat().st_size,sha256=sha(archive)),files=records,previews=videos,
        original_archive_modified=False,ios_integrated=False,ipa_generated=False,normal_speed_playback_review=False)
    (destination/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Archived',len(records),'source paths;',archive.stat().st_size,'bytes; ZIP CRC + source SHA256 + three previews verified',flush=True)

if __name__=='__main__':main()
